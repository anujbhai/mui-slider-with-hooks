import React from 'react';
import SwipeableTextMobileStepper from './../SwipeableTextMobileStepper';

const App = () => {
	return (
		<div>
			<SwipeableTextMobileStepper />
		</div>
	);
}

export default App;